package com.example.thesis;

public interface FormMessages{
    
    String getSuccessMessage();
    String getErrorMessage();
    void showError();
}
