<?php
	date_default_timezone_set('Asia/Hong_Kong');
	  
	$now = new DateTime();
	echo $now->format('Y-m-d'); 
?>